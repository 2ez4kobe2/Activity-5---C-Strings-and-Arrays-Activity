#include<stdio.h>
#include <stdlib.h>
#include <string.h>

void main(){
	char array[30];
	int size, x, vow = 0, cons = 0, num = 0, sChar = 0;
	
	printf("Enter string: ");
	fgets(array, sizeof(array), stdin);
	
	for(x = 0; x <= array[x] != '\0'; x++)
	{
		if(array[x] == 'A' || array[x] == 'E' || array[x] == 'I' || array[x] == 'O' || array[x] == 'U' || array[x] == 'a' || array[x] == 'e' || array[x] == 'i' || array[x] == 'o' || array[x] == 'u')
		{
			vow++;
		} else if((array[x] >= 'A' && array[x] <= 'Z') || (array[x] >= 'a' && array[x] <= 'z'))
		{
			cons++;
		} else if(array[x] >= '0' && array[x] <= '9')
		{
			num++;
		} else
		{
			sChar++;
		}
	}
	
	printf("\nVowels: %d\n", vow);
	printf("Consonants: %d\n", cons);
	printf("Numbers: %d\n", num);
	printf("Special Characters: %d", sChar);
}
