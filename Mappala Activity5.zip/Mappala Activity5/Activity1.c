#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#define size_of_array 5

void main(){
	char string[size_of_array][50], tempArray[30];
	int w, x, y, z;
	
	printf("Enter 5 strings: \n");
	
	for(w = 0; w < size_of_array; w++)
	{
		scanf("%s", &string[w]);
	}
	
	for(x = 0; x < (size_of_array - 1); x++)
	{
		for(y=0; y < (size_of_array - 1); y++)
		{
			if(strcmp(string[y], string[y+1]) > 0)
			{
				strcpy(tempArray, string[y]);
        		strcpy(string[y], string[y+1]);
        		strcpy(string[y+1], tempArray);
			}
		}
	}
	printf("\nSorted strings in ascending order:\n");
	for(z = 0; z < size_of_array; z++)
	{
		printf("%s ", string[z]);
		printf("\n");
	}
}
