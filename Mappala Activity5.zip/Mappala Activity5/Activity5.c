#include<stdio.h>
#include<math.h>

void main(){
	int x, y, row, col, first[20][20], second[20][20], sum[20][20];
	
	printf("Enter number of rows: ");
	scanf("%d", &row);
	printf("Enter number of columns: ");
	scanf("%d", &col);
	
	printf("Enter elements for first matrix:\n");
	for(x = 0; x < row; x++)
	{
		for(y = 0; y < col; y++)
		{
			printf("Element %d / %d: ", x + 1, y + 1);
			scanf("%d", &first[x][y]);
		}
	}
	
	printf("\nEnter elements for second matrix:\n");
	for(x = 0; x < row; x++)
	{
		for(y = 0; y < col; y++)
		{
			printf("Element %d / %d: ", x + 1, y + 1);
			scanf("%d", &second[x][y]);
		}
	}
	
	for(x = 0; x < row; x++)
	{
		for(y = 0; y < col; y++)
		{
			sum[x][y] = first[x][y] + second[x][y];
		}
	}
	
	printf("\nSum of two matrices: \n");
	for(x = 0; x < row; x++)
	{
		for(y = 0; y < col; y++)
		{
			printf("%d \t", sum[x][y]);
			if(y == col - 1)
			{
				printf("\n");
			}
		}
	}
}
