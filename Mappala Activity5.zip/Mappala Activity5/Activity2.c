#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#define size_of_array 100

void main(){
	char array1[size_of_array], array2[size_of_array], temp[size_of_array];
	int x = 0, y = 0;
	
	printf("Enter String 1: ");
	scanf("%s", array1);
	printf("Enter String 2: ");
	scanf("%s", array2);
	
	while(array1[x] != '\0')
	{
		temp[y] = array1[x];
		x++;
		y++;
	}
	
	x = 0;
	while(array2[x] != '\0')
	{
		temp[y] = array2[x];
		x++;
		y++;
	}
	
	temp[y] = '\0';
	
	printf("Output: %s", temp);
}
