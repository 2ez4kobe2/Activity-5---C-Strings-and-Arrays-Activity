#include<stdio.h>
#include<math.h>

void main(){
	int array[30], arraySize, x, largest;
	
	printf("Enter size of the array: ");
	scanf("%d", &arraySize);
	
	printf("Enter elements in array: ");
	for(x = 0; x < arraySize; x++)
	{
		scanf("%d", &array[x]);
	}
	
	largest = array[0];
    for(x = 1; x < arraySize; x++)
	{          
		if(largest < array[x])
		    {
		    	largest = array[x];
			}       
    }
    printf("Largest element of array is : %d", largest);
    printf("\n");
}
